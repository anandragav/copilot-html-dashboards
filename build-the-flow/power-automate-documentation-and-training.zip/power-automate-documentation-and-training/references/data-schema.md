# The DATA block

The template reads one object, `var DATA={...};`, placed between `/*FLOW_DATA_BEGIN*/` and `/*FLOW_DATA_END*/`. `build_page.py` writes it from the step graph and the handoff file. When Copilot fills the template by hand, it writes the same object. Keep it ASCII: write `\u00b7` for a middle dot and `\u2713` for a check mark, and never write `</` inside a string (write `<\/`).

```js
var DATA={
 "meta":{"title":"...","eyebrow":"...","lede":"...","summaryHeading":"You built the flow","summaryLead":"..."},
 "steps":[ /* one object per step, in build order (see below) */ ],
 "parts":[{"title":"Get the episode","steps":["When_a_feed_item_is_published"]}],
 "guards":[["Title","One or two sentences."]],
 "checks":{"title":"What you covered","center":"covered","caption":"...","items":[{"t":"...","done":true}]}
};
```

## Step objects

| Field | Use |
| --- | --- |
| `id` | The action name from the export. Empty arms use `<Condition>__empty_<yes/no/default>`. |
| `kind` | `node` (trigger or action), `loop` (Apply to each, Do until, Scope), or `cond` (Condition or Switch). |
| `trigger` | `true` on the first step. Adds the START sticker. |
| `loop` | `foreach`, `until`, or `scope` on loop steps. |
| `parent`, `branch` | The container id and branch: `actions` inside loops, `yes` / `no` for conditions, `case:<name>` / `default` for switches. Leave both out at the top level. |
| `armName`, `armLabel` | On the first step of each arm: `YES` and `YES \u00b7 new item`. |
| `title`, `sub`, `k` | Node title, the small second line, and the card kicker. |
| `icon`, `iconBg` | Up to three characters and a color for the node badge. |
| `what`, `why`, `cfg`, `tip` | Card copy. `cfg` is a list of `[label, value]`. |
| `crumb` | `[previous, next]` shown as "previous -> this step -> next". |
| `quiz` | `{"ask":"...","opts":[{"t":"...","ok":true,"fb":"..."}]}` with exactly one `ok`. |
| `guard` | `[number, "Guardrail title"]`. |
| `onFailure` | `true` when the step runs only after a failure. Adds an ON FAILURE sticker. |
| `empty` | `true` for a generated "No action" arm. Drawn in grey. |
| `packet` | A short label that travels down the arrow into the step. |
| `laps` | Do until only: the status pill text for each lap; the last one means "done". |
| `counter` | Apply to each only: `{"label":"items","count":12}`; items fan into the box. |

## Build order

List steps depth first: a container, then everything inside it, then the next sibling. For a condition: the condition, the whole YES arm, then the whole NO arm. The page uses this order for `#step=N` and for "Whole flow". The learner can build the arms of a condition in either order; the step after the condition unlocks only when every arm is built.

## Layout

There are no coordinates in `DATA`. The template stacks steps top to bottom, draws loops as dashed boxes around their inner steps, splits conditions and switches into side-by-side arms, merges the arms before the next step, and keeps the card clear of the surrounding box.

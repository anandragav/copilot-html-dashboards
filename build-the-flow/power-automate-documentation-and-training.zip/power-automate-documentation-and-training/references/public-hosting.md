# Optional public copy

If the user wants a public demo (for example on GitHub Pages), make a second file:

- `build_page.py ... --public-out page.public.html` writes the same page with pinned CDN copies of D3 7.9.0 and Chart.js 4.4.4 inserted at `<!--FT_PUBLIC_LIBS-->`.
- When filling the template by hand, put the same two `<script src>` tags at that marker in the public copy only.
- The public copy must use the same approved fictional values. Check it for real names again before publishing.
- Never put a CDN link in the SharePoint copy.

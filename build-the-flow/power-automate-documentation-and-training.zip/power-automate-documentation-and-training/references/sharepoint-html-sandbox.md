# SharePoint HTML sandbox rules for this page

The page is opened as an HTML file from a SharePoint document library or Site Pages, where SharePoint can supply approved libraries.

- **Libraries:** declare `<script type="application/json" class="ka-lib-manifest">["d3","chart.js"]</script>` in the head. SharePoint provides `window.d3` and `window.Chart`. Do not add `<script src>` tags or CDN links to the SharePoint copy.
- **Inline only:** one `<style>` and one main `<script>`. No external CSS, fonts, images, or iframes.
- **No network or storage:** no `fetch`, `XMLHttpRequest`, `localStorage`, `sessionStorage`, `indexedDB`, or cookies.
- **State in the hash:** `#step=N` restores the first N steps, `#done` restores the finish screen. Use `history.replaceState`.
- **ASCII only:** escape non-ASCII characters (`&#183;` in HTML, `\u00b7` in script).
- **Graceful fallback:** the page waits up to five seconds for D3. If it never arrives, it shows a plain-text version of every step, the guardrails, and the checklist. Chart.js is optional; without it the doughnut is hidden.
- **Accessibility:** keyboard (arrow keys, Enter, Escape), `prefers-reduced-motion`, live regions for the card, and a bottom-sheet card on narrow screens.
- **Where to open it:** upload the file to a library or Site Pages and open it there. Do not paste it into a text web part; that removes the script and styles.
